import 'package:app2/contato.dart';
import 'package:app2/segundatela.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Exemplo Rotas - Flutter/Dart',
      initialRoute: '/',
      routes: {
        // Associa e rota '/' ao Widget PrimeiraTela
        '/': (context) => const MyHomePage(title: 'Lista de Contatos'),
        // Associa a rota "/segunda" ao Widget SegundaTela
        '/segundatela': (context) =>
            const SegundaTelaPage(title: 'Cadastrar Contato'),
      },
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
    Navigator.pushNamed(context, '/segundatela', arguments: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: ListView.builder(
          itemCount: contatos.length,
          itemBuilder: (context, index) {
            return Card(
              elevation: 5,
              child: Container(
                width: 400,
                height: 130,
                color: Colors.transparent,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      width: 130,
                      height: 130,
                      color: Colors.transparent,
                      child: Image.asset('${contatos[index].foto}'),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text(
                            '${contatos[index].nome}',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 20,
                            ),
                          ),
                          Text('${contatos[index].fone}'),
                          Text('${contatos[index].email}'),
                          Text('${contatos[index].tipo}'),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            );
          }),

      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: const Icon(Icons.school),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
