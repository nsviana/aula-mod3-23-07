class Contato {
  String? nome;
  String? sexo;
  String? fone;
  String? email;
  String? tipo;
  String? foto;

  Contato(
    this.nome,
    this.sexo,
    this.fone,
    this.email,
    this.tipo,
    this.foto,
  );
}

List<Contato> contatos = [];
