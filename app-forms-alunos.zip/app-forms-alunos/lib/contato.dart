class Contato {
  String? nome;
  String? sexo;
  String? fone;
  String? email;
  String? tipo;
  String? foto;

  Contato(
    this.nome,
    this.sexo,
    this.fone,
    this.email,
    this.tipo,
    this.foto,
  );
}

List<Contato> contatos = [
  Contato('Pedro Silva Sousa', 'M', '+55 99 9999-2222', 'pedro.silva@gmail.com',
      'Pessoal', 'usuario-h.png'),
  Contato('Ana Sousa', 'M', '+55 99 9999-2222', 'pedro.silva@gmail.com',
      'Trabalho', 'usuario-m.png'),
  Contato('Ana Maria', 'F', '+55 99 9999-2222', 'pedro.silva@gmail.com',
      'Trabalho', 'usuario-m.png'),
  Contato('Ana Silva', 'F', '+55 99 9999-2222', 'pedro.silva@gmail.com',
      'Trabalho', 'usuario-m.png'),
  Contato('Pedsro Oliveira', 'M', '+55 99 9999-2222', 'pedro.silva@gmail.com',
      'Trabalho', 'usuario-m.png'),
];

//List<Contato> contatos = [];
