import 'package:app2/contato.dart';
import 'package:flutter/material.dart';

class SegundaTela extends StatelessWidget {
  const SegundaTela({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const SegundaTelaPage(title: 'Flutter Demo Home Page'),
    );
  }
}

class SegundaTelaPage extends StatefulWidget {
  const SegundaTelaPage({super.key, required this.title});

  final String title;

  @override
  State<SegundaTelaPage> createState() => _SegundaTelaPageState();
}

class _SegundaTelaPageState extends State<SegundaTelaPage> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  // Controller para cada um dos campos
  TextEditingController? nomeController = TextEditingController();
  TextEditingController? sexoController = TextEditingController();
  TextEditingController? foneController = TextEditingController();
  TextEditingController? emailController = TextEditingController();
  TextEditingController? tipoController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    dynamic telaAnterior = ModalRoute.of(context)!.settings.arguments;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: Form(
        child: ListView(
          padding: const EdgeInsets.all(10.0),
          children: <Widget>[
            TextFormField(
              controller: nomeController,
              decoration: const InputDecoration(
                labelText: 'Nome',
                hintText: 'Nome de usuário',
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black),
                ),
              ),
            ),
            TextFormField(
              controller: sexoController,
              decoration: const InputDecoration(
                labelText: 'Sexo',
                hintText: 'Sexo',
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black),
                ),
              ),
            ),
            TextFormField(
              controller: foneController,
              decoration: const InputDecoration(
                labelText: 'Fone',
                hintText: 'Fone do usuário',
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black),
                ),
              ),
            ),
            TextFormField(
              controller: emailController,
              decoration: const InputDecoration(
                labelText: 'Email',
                hintText: 'Email do usuário',
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black),
                ),
              ),
            ),
            TextFormField(
              controller: tipoController,
              decoration: const InputDecoration(
                labelText: 'Tipo',
                hintText: 'Tipo do usuário',
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black),
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                String imagem = "contato.png";
                if (sexoController!.text == 'M') {
                  imagem = 'assets/usuario-h.png';
                }
                if (sexoController!.text == 'F') {
                  imagem = 'assets/usuario-m.png';
                }
                Contato contato = Contato(
                    nomeController!.text,
                    sexoController!.text,
                    foneController!.text,
                    emailController!.text,
                    tipoController!.text,
                    imagem);
                contatos.add(contato);
                telaAnterior.setState(() {});
                Navigator.pop(context);
              },
              child: const Text(
                "Salvar",
                style: TextStyle(fontSize: 20),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
